# Salesforce Financial Services Cloud Test Pack (Variant B)

**5000 test cases (B‑variant)** covering the same modules as Zip A but with
- different permutations of actions (Create, Edit, AML Flag, Onboard, etc.),
- alternate domain‑module combinations,
- and extra compliance/AML/KYC‑focused scenarios.

## GitHub → Lovable Integration

```
kr-test-automator.lovable.app/salesforce/financial/variantB/
├── ?tab=overview (this HTML)
├── financial_services_cloud_5000_variantB.xlsx (Excel)
├── financial_services_cloud_5000_variantB.csv (dynamic table)
└── financial_services_cloud_5000_variantB.ts (app types)
```

**Upload this ZIP to**: `your-repo/salesforce/financial/fsc_5000_variantB_github_ready.zip`

**Generated**: April 19, 2026 by Perplexity AI