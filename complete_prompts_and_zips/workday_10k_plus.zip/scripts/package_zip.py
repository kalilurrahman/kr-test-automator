import zipfile
from pathlib import Path

def package(src_dir, zip_path):
    src_dir = Path(src_dir)
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for f in src_dir.rglob('*'):
            if f.is_file(): zf.write(f, f.relative_to(src_dir).as_posix())
