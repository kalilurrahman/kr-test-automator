from pathlib import Path

def write_index(title, links, path):
    html = f"<html><body><h1>{title}</h1>" + ''.join([f'<a href="{u}">{t}</a><br>' for t,u in links]) + '</body></html>'
    Path(path).write_text(html, encoding='utf-8')
