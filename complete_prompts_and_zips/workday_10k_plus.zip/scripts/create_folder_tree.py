from pathlib import Path

def ensure(path):
    Path(path).mkdir(parents=True, exist_ok=True)
