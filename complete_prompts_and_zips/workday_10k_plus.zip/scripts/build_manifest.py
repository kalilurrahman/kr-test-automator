import json
from pathlib import Path

def build(routes):
    return json.dumps({'routes': routes}, indent=2)
