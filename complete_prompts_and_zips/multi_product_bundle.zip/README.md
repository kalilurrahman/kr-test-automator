# Multi-Product Test Automator Bundle

Contains SAP, Salesforce, ServiceNow, and Workday structures plus shared scripts for GitHub + Jules + Lovable.
