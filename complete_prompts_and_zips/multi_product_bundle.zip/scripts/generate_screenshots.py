# use playwright or browser automation to capture screenshots
