# Workday Test Pack

1000 E2E-first test cases for Workday.

Files:
- workday_1000.csv
- workday_1000.xlsx
- workday_1000.html
- workday_1000.json
- workday_1000.ts
