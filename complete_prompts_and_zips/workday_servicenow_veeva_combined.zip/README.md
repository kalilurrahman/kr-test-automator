# Combined Workday + ServiceNow + Veeva Archive

Source-of-truth repo bundle for GitHub, Jules, and Lovable.
