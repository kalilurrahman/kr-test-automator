import zipfile
from pathlib import Path

zip_path = Path('workday_5000_github_ready.zip')
target_root = Path('workday')
target_root.mkdir(parents=True, exist_ok=True)

with zipfile.ZipFile(zip_path, 'r') as zf:
    zf.extractall(target_root / 'hcm')

print(f'Extracted {zip_path} into {target_root / "hcm"}')
