Validaira brand kit
Gold V with mint validation mark.
Includes SVG marks, PNG wordmark, launcher icons, maskable icon, favicon, social card and mobile artwork.
